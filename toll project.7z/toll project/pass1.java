import java.sql.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class pass1 extends JFrame implements ActionListener
{
JLabel l1,l2,l3,l4,l5;
JTextField t2,t3,t4,t5,t6;
JButton b1,b2,b3;
JComboBox t1;
public pass1()
{
setLayout(null);
l1=new JLabel("Vehicle no");
l1.setBounds(100,75,200,100);
l2=new JLabel("Pass no");
l2.setBounds(100,175,200,100);
l3=new JLabel("Date Of Issue");
l3.setBounds(100,275,200,100);
l4=new JLabel("Date Of Expiry");
l4.setBounds(100,375,200,100);
l5=new JLabel("Amount");
l5.setBounds(100,475,200,100);
b1=new JButton("DELETE");
b1.setBounds(200,600,100,40);
b1.addActionListener(this);
b2=new JButton("MODIFY");
b2.setBounds(300,600,100,40);
b2.addActionListener(this);
b3=new JButton("UPDATE");
b3.setBounds(400,600,100,40);
b3.addActionListener(this);
t1=new JComboBox();
t1.setBounds(300,100,200,40);
t1.addFocusListener(new FocusAdapter()
{
public void focusLost(FocusEvent fe)
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select * from pass where passno="+t1.getSelectedItem().toString());
rs.next();
t2.setText(String.valueOf(rs.getInt("vehicleno")));
t3.setText(String.valueOf(rs.getInt("doi")));
t4.setText(String.valueOf(rs.getInt("doe")));
t5.setText(String.valueOf(rs.getInt("amount")));	
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
});
t2=new JTextField(20);
t2.setBounds(300,200,200,40);
t3=new JTextField(20);
t3.setBounds(300,300,200,40);
t4=new JTextField(20);
t4.setBounds(300,400,200,40);
t5=new JTextField(20);
t5.setBounds(300,500,200,40);

add(l1);
add(t1);
add(l2);
add(t2);
add(l3);
add(t3);
add(l4);
add(t4);
add(l5);
add(t5);
add(b1);
add(b2);
add(b3);
getpassno();
}
void getpassno()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select passno from pass");
while(rs.next())
{
int s;
s=rs.getInt("passno");
t1.addItem(s);

}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}

public void actionPerformed(ActionEvent ae)
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
if(ae.getSource()==b1)
{
int y=JOptionPane.showConfirmDialog(null,"are you sure ?");
if (y==JOptionPane.YES_OPTION)
{
String query="delete passno from pass where passno="+t1.getSelectedItem().toString();
int x=stmt.executeUpdate(query);
JOptionPane.showMessageDialog(null,"one record deleted");
t2.setText("");
t3.setText("");
t4.setText("");
t5.setText("");
t1.removeAllItems();
getpassno();
}
}
else if (ae.getSource()==b2)
{
ResultSet rs=stmt.executeQuery("select * passno from pass where passno="+t1.getSelectedItem().toString());
rs.next();
t2.setText(String.valueOf(rs.getInt("vehicleno")));
t3.setText(rs.getString("doi"));
t4.setText(rs.getString("doe"));
t5.setText(rs.getString("amount"));
}
else if (ae.getSource()==b3)
{
String query="update emp set vehicleno="+t2.getText()+",doi ="+t3.getText()+",doe ="+t4.getText()+",amount="+t5.getText()+" where passno='"+t1.getSelectedItem().toString()+"'";
int z=stmt.executeUpdate(query);
JOptionPane.showMessageDialog(null,"one record updated");
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
public static void main(String args[])
{
pass1 p=new pass1();
p.setSize(1000,1000);
p.setVisible(true);
}
}