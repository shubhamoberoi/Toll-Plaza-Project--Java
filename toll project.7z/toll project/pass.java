import java.sql.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class pass extends JFrame implements ActionListener
{
JLabel l1,l2,l3,l4,l5;
JTextField t1,t2,t3,t4,t5;
JButton b1;
public pass()
{
setLayout(null);
l1=new JLabel("Vehicle no");
l1.setBounds(100,75,200,100);
l2=new JLabel("Pass no");
l2.setBounds(100,175,200,100);
l3=new JLabel("Date Of Issue");
l3.setBounds(100,275,200,100);
l4=new JLabel("Date Of Expiry");
l4.setBounds(100,375,200,100);
l5=new JLabel("Amount");
l5.setBounds(100,475,200,100);
b1=new JButton("Insert");
b1.setBounds(200,600,100,40);
b1.addActionListener(this);
t1=new JTextField(20);
t1.setBounds(300,100,200,40);
t2=new JTextField(20);
t2.setBounds(300,200,200,40);
t3=new JTextField(20);
t3.setBounds(300,300,200,40);
t4=new JTextField(20);
t4.setBounds(300,400,200,40);
t5=new JTextField(20);
t5.setBounds(300,500,200,40);
add(l1);
add(l2);
add(l3);
add(l4);
add(l5);
add(t1);
add(t2);
add(t3);
add(t4);
add(t5);
add(b1);
}
public void actionPerformed(ActionEvent ae)
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
String query="insert into pass(passno,vehicleno,doi,doe,amount) values("+t1.getText()+",'"+t2.getText()+"',"+t3.getText()+","+t4.getText()+","+t5.getText()+")";
int x=stmt.executeUpdate(query);
JOptionPane.showMessageDialog(null,"one record inserted");
con.close();
}
catch(Exception e)
{
System.out.println("caught exception"+e);
}
}
public static void main(String args[])
{
pass p=new pass();
p.setSize(1000,1000);
p.setVisible(true);
}
}