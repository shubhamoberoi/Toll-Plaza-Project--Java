import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class tlogin extends JFrame implements ActionListener
{
JLabel l3;
JButton b1,b2;
public tlogin()
{
setLayout(null);
l3=new JLabel("WELCOME TO TOLL PLAZA");
l3.setBounds(70,100,600,50);
Font f=new Font("ARIAL BLACK",Font.BOLD,35);
l3.setFont(f);
b1=new JButton("Login as user");
b1.setBounds(130,300,400,50);
b1.addActionListener(this);
b2=new JButton("Login as admin");
b2.setBounds(130,400,400,50);
b2.addActionListener(this);
add(b2);
add(b1);
add(l3);
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b1)
{
dispose();
login n=new login();
n.setVisible(true);
n.setSize(700,700);
}
if(ae.getSource()==b2)
{
dispose();
admilog q=new admilog();
q.setVisible(true);
q.setSize(700,700);
}
}
public static void main(String args[])
{
tlogin n=new tlogin();
n.setVisible(true);
n.setSize(700,700);
}
}