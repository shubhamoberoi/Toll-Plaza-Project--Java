import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class login1 extends JFrame implements ActionListener
{
JLabel l1,l2,l3;
JTextField t1;
JPasswordField t2;
JButton b1,b2;
public login1()
{
setLayout(null);
l1=new JLabel("User");
l1.setBounds(175,190,100,50);
l2=new JLabel("Password");
l2.setBounds(175,290,100,50);
l3=new JLabel("SIGNUP SCREEN");
l3.setBounds(150,50,500,50);
Font f=new Font("ARIAL BLACK",Font.BOLD,35);
l3.setFont(f);
t1=new JTextField(20);
t1.setBounds(275,200,150,30);
t2=new JPasswordField(20);
t2.setBounds(275,300,150,30);
b1=new JButton("Create");
b1.setBounds(170,400,75,50);
b1.addActionListener(this);
b2=new JButton("Back");
b2.setBounds(320,400,75,50);
b2.addActionListener(this);
add(l1); 
add(l2);
add(t1);
add(t2);
add(b2);
add(b1);
add(l3);
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b1)
{
	try
	{
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection con=DriverManager.getConnection("jdbc:odbc:toll");
	Statement stmt=con.createStatement();
	ResultSet rs=stmt.executeQuery("select * from users where username='"+t1.getText()+"' and password='"+t2.getText()+"'");
	int c=0;
	while(rs.next())
	{
		JOptionPane.showMessageDialog(null,"Username and Password already exists");
		t1.setText("");
		t2.setText("");
		t1.requestFocus();
		c=1;
	}
	if(c==0)
	{
		String query="Insert into users(username,password) values ('"+t1.getText()+"','"+t2.getText()+"')";
		int x=stmt.executeUpdate(query);
		JOptionPane.showMessageDialog(null,"User Created");
		t1.setText("");
		t2.setText("");
		
	}
	con.close();
	}
	catch(Exception ex)
	{
		System.out.println("Error Occured"+ex);
	}
}
else if(ae.getSource()==b2)
{
dispose();
tmenu q=new tmenu();
q.setVisible(true);
q.setSize(700,700);
}
}

public static void main(String args[])
{
login1 n=new login1();
n.setVisible(true);
n.setSize(650,650);
}
}
