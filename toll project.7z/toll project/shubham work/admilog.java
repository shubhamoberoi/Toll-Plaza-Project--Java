import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class admilog extends JFrame implements ActionListener
{
JLabel l1,l2,l3;
JTextField t1;
JPasswordField t2;
JButton b1,b3;
public admilog()
{
setLayout(null);
l1=new JLabel("User");
l1.setBounds(175,190,100,50);
l2=new JLabel("Password");
l2.setBounds(175,290,100,50);
l3=new JLabel("ADMIN LOGIN SCREEN");
l3.setBounds(100,50,500,50);
Font f=new Font("ARIAL BLACK",Font.BOLD,35);
l3.setFont(f);
t1=new JTextField(20);
t1.setBounds(275,200,150,30);
t2=new JPasswordField(20);
t2.setBounds(275,300,150,30);
b1=new JButton("Login");
b1.setBounds(175,400,75,50);
b1.addActionListener(this);
b3=new JButton("Exit");
b3.setBounds(300,400,75,50);
b3.addActionListener(this);
add(l1); 
add(l2);
add(t1);
add(t2);
add(b3);
add(b1);
add(l3);
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b1)
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select * from admin where adminame='"+t1.getText()+"' and admipass='"+t2.getText()+"'");
int c=0;
while(rs.next())
{
JOptionPane.showMessageDialog(null,"login successful");
dispose();
tmenu q=new tmenu();
q.setVisible(true);
q.setSize(700,700);
c=1;
}
if(c==0)
{
JOptionPane.showMessageDialog(null," Invalid Username/Password");
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
else if(ae.getSource()==b3)
{
System.exit(0);
}
}
public static void main(String args[])
{
admilog q=new admilog();
q.setVisible(true);
q.setSize(700,700);
}
}