import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class tmenu extends JFrame implements ActionListener
{
JMenuItem a,m,n;
tmenu()
{
JMenuBar mbar=new JMenuBar();
setJMenuBar(mbar);

JMenu s=new JMenu("Vehicle Details");
mbar.add(s);

JMenu t=new JMenu("Monthly Pass");
mbar.add(t);

JMenu k=new JMenu("Login");
mbar.add(k);

JMenu r=new JMenu("Reports");
mbar.add(r);

JMenu e=new JMenu("Exit");
mbar.add(e);

n=new JMenuItem("Create New User");
k.add(n);
n.addActionListener(this);


a=new JMenuItem("Add");
s.add(a);
s.addSeparator();
a.addActionListener(this);
m=new JMenuItem("Modify/Delete");
s.add(m);
m.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==a)
{
dispose();
vehicle v=new vehicle();
v.setSize(700,700);
v.setVisible(true);
}
if(ae.getSource()==m)
{
dispose();
vehicle1 v=new vehicle1();
v.setSize(700,700);
v.setVisible(true);
}
if(ae.getSource()==n)
{
dispose();
login1 n=new login1();
n.setVisible(true);
n.setSize(650,650);
}
}
public static void main(String args[])
{
tmenu q=new tmenu();
q.setVisible(true);
q.setSize(700,700);
}
}