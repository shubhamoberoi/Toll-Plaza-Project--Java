import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class vehicle1 extends JFrame implements ActionListener	
{
JLabel l1,l2,l3,l4,l5;
JComboBox t1;
JTextField t2,t3,t4;
JButton b1,b2,b3,b4;
public vehicle1()
{
setLayout(null);
l5=new JLabel("VEHICLE DETAILS");
l5.setBounds(350,10,100,30);
l1=new JLabel("Vehicle Type");
l1.setBounds(200,100,200,30);
l2=new JLabel("One Way");
l2.setBounds(200,200,200,30);
l3=new JLabel("Two Way");
l3.setBounds(200,300,200,30);
l4=new JLabel("Pass");
l4.setBounds(200,400,200,30);
t1=new JComboBox();
t1.setBounds(350,100,200,30);
t2=new JTextField(20);
t2.setBounds(350,200,200,30);
t3=new JTextField(20);
t3.setBounds(350,300,200,30);
t4=new JTextField(20);
t4.setBounds(350,400,200,30);
b1=new JButton("DELETE");
b1.setBounds(100,500,100,30);
b1.addActionListener(this);
b2=new JButton("MODIFY");
b2.setBounds(250,500,100,30);
b2.addActionListener(this);
b3=new JButton("UPDATE");
b3.setBounds(400,500,100,30);
b3.addActionListener(this);
b4=new JButton("HOME");
b4.setBounds(550,500,100,30);
b4.addActionListener(this);
add(l1);
add(t1);
add(l2);
add(t2);
add(l3);
add(t3);
add(l4);
add(t4);
add(b1);
add(b2);
add(b3);
add(l5);
add(b4);
getvehicletype();
}
void getvehicletype()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select vehicletype from vehicle where vehicletype='"+t1.getSelectedItem().toString()+"'");
while(rs.next())
{
String s;
s=rs.getString("Vehicletype");
t1.addItem(s);
System.out.println(s);
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
public void actionPerformed(ActionEvent ae)
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
if(ae.getSource()==b1)
{
int y=JOptionPane.showConfirmDialog(null,"are you sure ?");
if (y==JOptionPane.YES_OPTION)
{
String query="delete from vehicletype from vehicle where vehicletype='"+t1.getSelectedItem().toString()+"'";
int x=stmt.executeUpdate(query);
JOptionPane.showMessageDialog(null,"one record deleted");
t2.setText("");
t3.setText("");
t4.setText("");
t1.removeAllItems();
getvehicletype();
}
}
else if (ae.getSource()==b2)
{
ResultSet rs=stmt.executeQuery("select * vehicletype from vehicle where vehicletype='"+t1.getSelectedItem().toString()+"'");
rs.next();
t2.setText(String.valueOf(rs.getInt("oneway")));
t3.setText(String.valueOf(rs.getInt("twoway")));
t4.setText(String.valueOf(rs.getInt("pass")));
}
else if (ae.getSource()==b4)
{
dispose();
tmenu q=new tmenu();
q.setVisible(true);
q.setSize(700,700);
}
else if (ae.getSource()==b3)
{
String query="update emp set oneway="+t2.getText()+",twoway ="+t3.getText()+",pass ="+t4.getText()+" where vehicletype='"+t1.getSelectedItem().toString()+"'";
int z=stmt.executeUpdate(query);
JOptionPane.showMessageDialog(null,"one record updated");
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
public static void main(String args[])
{
vehicle1 v=new vehicle1();
v.setSize(700,700);
v.setVisible(true);
}
}
