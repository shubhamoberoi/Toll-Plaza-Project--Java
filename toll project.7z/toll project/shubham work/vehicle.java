import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;
public class vehicle extends JFrame implements ActionListener
{
JLabel l1,l2,l3,l4,l5;
JTextField t1,t2,t3,t4;
JButton b1,b2,b3;
public vehicle()
{
setLayout(null);
l5=new JLabel("VEHICLE DETAILS");
l5.setBounds(350,10,100,30);
l1=new JLabel("Vehicle Type");
l1.setBounds(200,100,200,30);
l2=new JLabel("One Way");
l2.setBounds(200,200,200,30);
l3=new JLabel("Two Way");
l3.setBounds(200,300,200,30);
l4=new JLabel("Pass");
l4.setBounds(200,400,200,30);
t1=new JTextField(20);
t1.setBounds(350,100,200,30);
t1.addFocusListener(new FocusAdapter()
{
public void focusLost(FocusEvent fe)
{
getvehiclename();
}
});
t2=new JTextField(20);
t2.setBounds(350,200,200,30);
t3=new JTextField(20);
t3.setBounds(350,300,200,30);
t4=new JTextField(20);
t4.setBounds(350,400,200,30);
b1=new JButton("INSERT");
b1.setBounds(170,500,100,30);
b2=new JButton("CLEAR");
b2.setBounds(320,500,100,30);
b2.addActionListener(this);
b3=new JButton("HOME");
b3.setBounds(470,500,100,30);
b3.addActionListener(this);
add(l1);
add(t1);
add(l2);
add(t2);
add(l3);
add(t3);
add(l4);
add(t4);
add(b1);
b1.addActionListener(this);
add(b2);
add(b3);
add(l5);
}
void getvehiclename()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select vehicletype from vehicle where vehicletype='"+t1.getText()+"'");

while(rs.next())
{
JOptionPane.showMessageDialog(null,"Vehicle Type already exists");
t1.setText("");
t1.requestFocus();
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b1)
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
String query="Insert into vehicle(vehicletype,oneway,twoway,pass) values ('"+t1.getText()+"',"+t2.getText()+","+t3.getText()+","+t4.getText()+")";
int x=stmt.executeUpdate(query);
JOptionPane.showMessageDialog(null,"one record inserted");
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}
else if(ae.getSource()==b2)
{
t2.setText("");
t3.setText("");
t4.setText("");
}
else if(ae.getSource()==b3)
{
dispose();
tmenu q=new tmenu();
q.setVisible(true);
q.setSize(700,700);
}
}
public static void main(String args[])
{
vehicle v=new vehicle();
v.setSize(700,700);
v.setVisible(true);
}
}