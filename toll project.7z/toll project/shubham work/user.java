import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;
public class user extends JFrame
{
JLabel l1,l4,l5,l6,l7,l8,l9;
JComboBox t1,b1;

JTextField t2,t3,t4,t5,t6;
JButton b2,b3;
public user()
{
setLayout(null);
l7=new JLabel("Recipt no");
l7.setBounds(200,50,200,30);
t4=new JTextField(50);
t4.setBounds(350,50,150,30);

l8=new JLabel("Date and Time");
l8.setBounds(200,100,100,30);
t5=new JTextField(20);
t5.setBounds(350,100,150,30);
java.util.Date d=new java.util.Date();
t5.setText(""+d.toLocaleString());


l1=new JLabel("Vehicle Type");
l1.setBounds(200,150,100,30);
t1=new JComboBox();
t1.setBounds(350,150,150,30);

l6=new JLabel("Vehicle no");
l6.setBounds(200,200,100,30);
t3=new JTextField(20);
t3.setBounds(350,200,150,30);

l4=new JLabel("Journey Type");
l4.setBounds(200,250,100,30);

l5=new JLabel("Rate");
l5.setBounds(200,300,100,30);
t2=new JTextField(20);
t2.setBounds(350,300,150,30);

b1=new JComboBox();
b1.setBounds(350,250,100,30);
b1.addItem("one way");
b1.addItem("two way");
b1.addFocusListener(new FocusAdapter()
{
public void focusLost(FocusEvent fe)
{
getrate();
}
});
add(l1);
add(t1);
add(b1);
add(l4);
add(l5);
add(t2);
add(l6);
add(t3);
add(t4);
add(l7);
add(l8);
add(t5);
getvehicletype();
}
void getvehicletype()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select vehicletype from vehicle");
while(rs.next())
{
String ec;
ec=rs.getString("vehicletype");
t1.addItem(ec);
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}

void getrate()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:toll");
Statement stmt=con.createStatement();
ResultSet rs;
if(b1.getSelectedItem().toString().equals("one way"))
	rs=stmt.executeQuery("select oneway from vehicle where vehicletype='"+t1.getSelectedItem().toString()+"'");
else 
	rs=stmt.executeQuery("select twoway from vehicle where vehicletype='"+t1.getSelectedItem().toString()+"'");

while(rs.next())
{
t2.setText(""+rs.getInt(1));
}
con.close();
}
catch(Exception ex)
{
System.out.println("Error Occured"+ex);
}
}





public static void main(String args[])
{
user n=new user();
n.setVisible(true);
n.setSize(700,700);
}
}